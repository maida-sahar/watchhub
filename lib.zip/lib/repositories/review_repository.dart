import 'package:image_picker/image_picker.dart';

import '../services/review_service.dart';

/// Exception wrapper for ReviewRepository failures.
class ReviewRepositoryException implements Exception {
  final String message;
  const ReviewRepositoryException(this.message);

  @override
  String toString() => message;
}

/// Repository abstracting Firestore access for product reviews.
class ReviewRepository {
  final ReviewService _service;

  ReviewRepository({required ReviewService service}) : _service = service;

  /// Exposes a stream of all reviews.
  Stream<List<ReviewModel>> watchAllReviews() {
    return _service.watchAllReviews();
  }

  /// Approves a review.
  Future<void> approveReview(String reviewId) async {
    try {
      await _service.approveReview(reviewId);
    } catch (e) {
      throw ReviewRepositoryException(e.toString());
    }
  }

  /// Rejects a review.
  Future<void> rejectReview(String reviewId) async {
    try {
      await _service.rejectReview(reviewId);
    } catch (e) {
      throw ReviewRepositoryException(e.toString());
    }
  }

  /// Hides a review.
  Future<void> hideReview(String reviewId) async {
    try {
      await _service.hideReview(reviewId);
    } catch (e) {
      throw ReviewRepositoryException(e.toString());
    }
  }

  /// Unhides a review.
  Future<void> unhideReview(String reviewId) async {
    try {
      await _service.unhideReview(reviewId);
    } catch (e) {
      throw ReviewRepositoryException(e.toString());
    }
  }

  /// Deletes a review permanently.
  Future<void> deleteReview(String reviewId) async {
    try {
      await _service.deleteReview(reviewId);
    } catch (e) {
      throw ReviewRepositoryException(e.toString());
    }
  }

  /// Resolves a reported review.
  Future<void> resolveReport(String reviewId) async {
    try {
      await _service.resolveReport(reviewId);
    } catch (e) {
      throw ReviewRepositoryException(e.toString());
    }
  }

  /// Dismisses a report.
  Future<void> dismissReport(String reviewId) async {
    try {
      await _service.dismissReport(reviewId);
    } catch (e) {
      throw ReviewRepositoryException(e.toString());
    }
  }

  /// Uploads a review image and returns public URL.
  Future<String> uploadReviewImage({
    required String reviewId,
    required XFile imageFile,
  }) async {
    try {
      return await _service.uploadReviewImage(
        reviewId: reviewId,
        imageFile: imageFile,
      );
    } catch (e) {
      throw ReviewRepositoryException(e.toString());
    }
  }
}
