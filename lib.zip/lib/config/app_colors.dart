import 'package:flutter/material.dart';

class AppColors {
  // ---- Brand (Luxury Copper Brown) ----
  static const Color primary = Color(0xFFB87352);      // Copper Brown
  static const Color primaryLight = Color(0xFFD6B89B); // Secondary
  static const Color accent = Color(0xFF8B5E3C);       // Darker accent

  // ---- Neutrals ----
  static const Color background = Color(0xFFF8F8F8);
  static const Color surface = Color(0xFFFFFFFF);
  static const Color surfaceVariant = Color(0xFFF5F5F5);
  static const Color textPrimary = Color(0xFF1F2937);
  static const Color textSecondary = Color(0xFF8B8B8B);
  static const Color textTertiary = Color(0xFFBDBDBD);
  static const Color border = Color(0xFFECECEC);
  static const Color divider = Color(0xFFECECEC);

  // ---- Semantic ----
  static const Color onPrimary = Colors.white;
  static const Color success = Color(0xFF2E7D32);
  static const Color error = Color(0xFFD32F2F);

  // ---- Icons ----
  static const Color iconPrimary = Color(0xFF1F2937);
  static const Color iconSecondary = Color(0xFF8B8B8B);

  // ---- Claymorphism shadows (use these with opacity) ----
  static const Color shadow = Color(0xFF000000);

  // ---- Material 3 ColorScheme ----
  static ColorScheme get lightScheme {
    return ColorScheme.fromSeed(
      seedColor: primary,
      brightness: Brightness.light,
      primary: primary,
      onPrimary: onPrimary,
      secondary: primaryLight,
      onSecondary: Colors.white,
      error: error,
      onError: Colors.white,
      surface: surface,
      onSurface: textPrimary,
      surfaceVariant: surfaceVariant,
      onSurfaceVariant: textSecondary,
      outline: border,
      shadow: shadow,
    );
  }
}