import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/auth_status.dart';
import '../../providers/auth_provider.dart';

/// First screen the app shows. Its only job is:
///   1. Kick off AuthProvider.initializeAuth() once.
///   2. Watch AuthProvider.authStatus.
///   3. As soon as status settles into a terminal state, ask the
///      provider where to go (navigateBasedOnRole()) and navigate there.
///
/// No business logic lives here — this screen never talks to Firebase,
/// FirestoreService, or AuthRepository directly, per "Only Provider
/// should decide navigation."
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  bool _started = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Guard against re-triggering on every rebuild; initializeAuth()
    // should run exactly once per app launch.
    if (!_started) {
      _started = true;
      // Deferred to post-frame so context/provider are fully mounted.
      WidgetsBinding.instance.addPostFrameCallback((_) {
        context.read<AuthProvider>().initializeAuth();
      });
    }
  }

  void _navigateIfSettled(BuildContext context, AuthProvider auth) {
    const settledStates = {
      AuthStatus.authenticatedCustomer,
      AuthStatus.authenticatedAdmin,
      AuthStatus.unauthenticated,
      AuthStatus.error,
    };
    if (!settledStates.contains(auth.authStatus)) return;

    final destination = auth.navigateBasedOnRole();

    // Defer navigation to post-frame: this callback can fire mid-build
    // (Consumer rebuild) and Navigator must not be driven during build.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      Navigator.of(context).pushNamedAndRemoveUntil(
        destination,
        (route) => false,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AuthProvider>(
      builder: (context, auth, _) {
        _navigateIfSettled(context, auth);

        return Scaffold(
          body: Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // TODO: swap for your WatchHub logo asset.
                const FlutterLogo(size: 96),
                const SizedBox(height: 24),
                if (auth.authStatus == AuthStatus.uninitialized ||
                    auth.authStatus == AuthStatus.authenticating)
                  const CircularProgressIndicator(),
              ],
            ),
          ),
        );
      },
    );
  }
}