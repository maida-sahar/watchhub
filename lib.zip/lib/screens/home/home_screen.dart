// home_screen.dart
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:watch_hub/config/app_colors.dart';
import 'package:watch_hub/config/app_spacing.dart';
import 'package:watch_hub/config/app_typography.dart';
import 'package:watch_hub/config/clay_widgets.dart';

import '../../config/app_routes.dart';
import '../../providers/auth_provider.dart';
import '../../providers/notification_provider.dart';

// ---------- Mock Data (replace with your real models later) ----------
class CarouselItem {
  final String imageUrl;
  final String collectionTitle;
  final String heading;
  final String description;
  final double rating;
  final String ctaText;
  final VoidCallback? onTap;

  CarouselItem({
    required this.imageUrl,
    required this.collectionTitle,
    required this.heading,
    required this.description,
    required this.rating,
    required this.ctaText,
    this.onTap,
  });
}

class Product {
  final String imageUrl;
  final String brand;
  final String name;
  final double price;
  final double? discountPrice;
  final double rating;
  final bool isNew;
  final bool isOnSale;
  final bool isBestSeller;

  Product({
    required this.imageUrl,
    required this.brand,
    required this.name,
    required this.price,
    this.discountPrice,
    required this.rating,
    this.isNew = false,
    this.isOnSale = false,
    this.isBestSeller = false,
  });
}

// Sample data (replace with your actual product data)
final List<CarouselItem> carouselItems = [
  CarouselItem(
    imageUrl: 'https://via.placeholder.com/800x400/0D1B2A/FFFFFF?text=Rolex+Daytona',
    collectionTitle: 'TIMELESS ELEGANCE',
    heading: 'Rolex Daytona',
    description: 'The ultimate chronograph for the discerning collector.',
    rating: 4.9,
    ctaText: 'Explore Collection',
  ),
  CarouselItem(
    imageUrl: 'https://via.placeholder.com/800x400/1a2a3a/FFFFFF?text=Omega+Speedmaster',
    collectionTitle: 'LEGENDARY HERITAGE',
    heading: 'Omega Speedmaster',
    description: 'The first watch on the moon. A piece of history.',
    rating: 4.8,
    ctaText: 'Shop Now',
  ),
  CarouselItem(
    imageUrl: 'https://via.placeholder.com/800x400/2a3a4a/FFFFFF?text=Audemars+Piguet',
    collectionTitle: 'HAUTE HORLOGERIE',
    heading: 'Audemars Piguet Royal Oak',
    description: 'Iconic design with a bold, octagonal bezel.',
    rating: 4.9,
    ctaText: 'Discover',
  ),
];

final List<Product> sampleProducts = [
  Product(
    imageUrl: 'https://via.placeholder.com/200x200/0D1B2A/FFFFFF?text=Watch+1',
    brand: 'Rolex',
    name: 'Submariner Date',
    price: 12500,
    discountPrice: 11250,
    rating: 4.9,
    isNew: true,
  ),
  Product(
    imageUrl: 'https://via.placeholder.com/200x200/1a2a3a/FFFFFF?text=Watch+2',
    brand: 'Omega',
    name: 'Seamaster Diver 300M',
    price: 5500,
    rating: 4.7,
    isOnSale: true,
  ),
  Product(
    imageUrl: 'https://via.placeholder.com/200x200/2a3a4a/FFFFFF?text=Watch+3',
    brand: 'IWC',
    name: 'Pilot\'s Watch Chronograph',
    price: 7800,
    rating: 4.8,
    isBestSeller: true,
  ),
  Product(
    imageUrl: 'https://via.placeholder.com/200x200/3a4a5a/FFFFFF?text=Watch+4',
    brand: 'Cartier',
    name: 'Tank Solo',
    price: 3200,
    rating: 4.6,
    isNew: true,
  ),
  Product(
    imageUrl: 'https://via.placeholder.com/200x200/4a5a6a/FFFFFF?text=Watch+5',
    brand: 'Tag Heuer',
    name: 'Carrera Calibre 16',
    price: 4200,
    discountPrice: 3800,
    rating: 4.5,
    isOnSale: true,
  ),
];

// ---------- Main Home Screen ----------
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  final PageController _carouselController = PageController();
  int _currentCarouselIndex = 0;
  int _selectedCategoryIndex = 0;
  int _selectedNavIndex = 0; // for bottom nav

  final List<String> _categories = [
    'All',
    'Men',
    'Women',
    'Luxury',
    'Smart',
    'Sports',
    'casual',
    'New Arrival'
  ];

  // Bottom navigation items
  final List<BottomNavigationBarItem> _navItems = const [
    BottomNavigationBarItem(icon: Icon(Icons.home_rounded), label: 'Home'),
    BottomNavigationBarItem(icon: Icon(Icons.search_rounded), label: 'Search'),
    BottomNavigationBarItem(icon: Icon(Icons.favorite_border_rounded), label: 'Wishlist'),
    BottomNavigationBarItem(icon: Icon(Icons.shopping_cart_outlined), label: 'Cart'),
    BottomNavigationBarItem(icon: Icon(Icons.person_outline_rounded), label: 'Profile'),
  ];

  @override
  void initState() {
    super.initState();
    // Auto-slide carousel
    Future.delayed(const Duration(seconds: 3), _autoSlide);
  }

  void _autoSlide() {
    if (!mounted) return;
    if (_carouselController.hasClients) {
      final nextPage = (_currentCarouselIndex + 1) % carouselItems.length;
      _carouselController.animateToPage(
        nextPage,
        duration: const Duration(milliseconds: 600),
        curve: Curves.easeInOut,
      );
      setState(() => _currentCarouselIndex = nextPage);
      Future.delayed(const Duration(seconds: 4), _autoSlide);
    } else {
      Future.delayed(const Duration(milliseconds: 100), _autoSlide);
    }
  }

  @override
  void dispose() {
    _carouselController.dispose();
    super.dispose();
  }

  // Handle bottom nav taps – navigate to appropriate screens
  void _onNavTap(int index) {
    setState(() => _selectedNavIndex = index);
    switch (index) {
      case 0:
        // Already on home, do nothing or scroll to top
        break;
      case 1:
        Navigator.pushNamed(context, AppRoutes.search);
        break;
      case 2:
        Navigator.pushNamed(context, AppRoutes.customerWishlist);
        break;
      case 3:
        Navigator.pushNamed(context, AppRoutes.customerCart);
        break;
      case 4:
        Navigator.pushNamed(context, AppRoutes.customerProfile);
        break;
    }
    // Reset index to 0 after navigation (so home stays selected when returning)
    // But if we set it to 0 immediately, the bottom nav would flash. Better to keep as is,
    // but we want the home icon to remain selected when on home.
    // We'll set it back to 0 when we return to home (via didChangeDependencies or onResume).
    // However, since we are pushing a new route, the bottom nav will not be visible on those screens.
    // When we come back, this screen will rebuild with _selectedNavIndex = 0 (initial value).
    // So we can set it to 0 in initState and leave it.
  }

  Future<void> _handleLogout(BuildContext context) async {
    try {
      await context.read<NotificationProvider>().removeTokenOnLogout();
    } catch (_) {}
    final auth = context.read<AuthProvider>();
    await auth.logout();
    if (!context.mounted) return;
    Navigator.of(context).pushNamedAndRemoveUntil(
      AppRoutes.login,
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: _buildAppBar(context),
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Category chips (Quick Actions)
              _CategoryChips(
                categories: _categories,
                selectedIndex: _selectedCategoryIndex,
                onTap: (index) {
                  setState(() => _selectedCategoryIndex = index);
                  // In a real app, filter products by category.
                },
              ),
              const SizedBox(height: AppSpacing.lg),

              // Hero Carousel
              _HeroCarousel(
                controller: _carouselController,
                currentIndex: _currentCarouselIndex,
                onPageChanged: (index) {
                  setState(() => _currentCarouselIndex = index);
                },
                items: carouselItems,
              ),
              const SizedBox(height: AppSpacing.xxl),

              // New Arrivals
              _SectionHeader(title: 'New Arrivals', seeAll: () {}),
              const SizedBox(height: AppSpacing.md),
              _ProductHorizontalList(products: sampleProducts.where((p) => p.isNew).toList()),

              // Featured Brands
              const SizedBox(height: AppSpacing.xxl),
              _SectionHeader(title: 'Featured Brands', seeAll: () {}),
              const SizedBox(height: AppSpacing.md),
              _BrandsRow(),

              // Trending Products
              const SizedBox(height: AppSpacing.xxl),
              _SectionHeader(title: 'Trending', seeAll: () {}),
              const SizedBox(height: AppSpacing.md),
              _ProductHorizontalList(products: sampleProducts),

              // Flash Sale
              const SizedBox(height: AppSpacing.xxl),
              _SectionHeader(title: 'Flash Sale', seeAll: () {}),
              const SizedBox(height: AppSpacing.md),
              _ProductHorizontalList(products: sampleProducts.where((p) => p.isOnSale).toList()),

              // Best Sellers
              const SizedBox(height: AppSpacing.xxl),
              _SectionHeader(title: 'Best Sellers', seeAll: () {}),
              const SizedBox(height: AppSpacing.md),
              _ProductHorizontalList(products: sampleProducts.where((p) => p.isBestSeller).toList()),

              // Recently Viewed
              const SizedBox(height: AppSpacing.xxl),
              _SectionHeader(title: 'Recently Viewed', seeAll: () {}),
              const SizedBox(height: AppSpacing.md),
              _ProductHorizontalList(products: sampleProducts),

              // Customer Reviews
              const SizedBox(height: AppSpacing.xxl),
              _SectionHeader(title: 'Customer Reviews', seeAll: () {}),
              const SizedBox(height: AppSpacing.md),
              _ReviewList(),

              const SizedBox(height: AppSpacing.xxl),
            ],
          ),
        ),
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      title: Text(
        'WatchHub',
        style: GoogleFonts.playfairDisplay(
          fontSize: 26,
          fontWeight: FontWeight.bold,
          color: AppColors.primary,
        ),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.notifications_outlined, color: AppColors.textPrimary),
          onPressed: () => Navigator.pushNamed(context, AppRoutes.notifications),
        ),
        // Removed logout from AppBar as per requirement
      ],
    );
  }

  Widget _buildBottomNav() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 20,
            offset: const Offset(0, -4),
          ),
        ],
      ),
      child: SafeArea(
        child: BottomNavigationBar(
          currentIndex: _selectedNavIndex,
          onTap: _onNavTap,
          type: BottomNavigationBarType.fixed,
          selectedItemColor: const Color(0xFFC8A96A), // Accent
          unselectedItemColor: AppColors.textSecondary,
          selectedFontSize: 12,
          unselectedFontSize: 12,
          showSelectedLabels: true,
          showUnselectedLabels: true,
          elevation: 0,
          backgroundColor: Colors.transparent,
          items: _navItems,
        ),
      ),
    );
  }
}

// ---------- Widgets ----------

class _CategoryChips extends StatelessWidget {
  final List<String> categories;
  final int selectedIndex;
  final ValueChanged<int> onTap;

  const _CategoryChips({
    required this.categories,
    required this.selectedIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 48,
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenPadding),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: AppSpacing.sm),
        itemBuilder: (context, index) {
          final isSelected = index == selectedIndex;
          return GestureDetector(
            onTap: () => onTap(index),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeInOut,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              decoration: BoxDecoration(
                color: isSelected ? AppColors.primary : Colors.white,
                borderRadius: BorderRadius.circular(30),
                border: Border.all(
                  color: isSelected ? AppColors.primary : AppColors.textSecondary.withOpacity(0.3),
                ),
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                          color: AppColors.primary.withOpacity(0.2),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        )
                      ]
                    : null,
              ),
              child: Text(
                categories[index],
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                  color: isSelected ? Colors.white : AppColors.textPrimary,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _HeroCarousel extends StatelessWidget {
  final PageController controller;
  final int currentIndex;
  final ValueChanged<int> onPageChanged;
  final List<CarouselItem> items;

  const _HeroCarousel({
    required this.controller,
    required this.currentIndex,
    required this.onPageChanged,
    required this.items,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 380,
      child: Stack(
        children: [
          PageView.builder(
            controller: controller,
            onPageChanged: onPageChanged,
            itemCount: items.length,
            itemBuilder: (context, index) {
              final item = items[index];
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: AppSpacing.screenPadding),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  image: DecorationImage(
                    image: NetworkImage(item.imageUrl),
                    fit: BoxFit.cover,
                  ),
                ),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(24),
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                      colors: [
                        Colors.black.withOpacity(0.7),
                        Colors.black.withOpacity(0.1),
                      ],
                    ),
                  ),
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        item.collectionTitle,
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 2,
                          color: const Color(0xFFC8A96A),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        item.heading,
                        style: GoogleFonts.playfairDisplay(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        item.description,
                        style: GoogleFonts.poppins(
                          fontSize: 14,
                          color: Colors.white70,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          const Icon(Icons.star, color: Color(0xFFC8A96A), size: 18),
                          const SizedBox(width: 4),
                          Text(
                            item.rating.toString(),
                            style: GoogleFonts.poppins(
                              fontSize: 14,
                              fontWeight: FontWeight.w500,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: item.onTap ?? () {},
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF111111),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                          textStyle: GoogleFonts.inter(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        child: Text(item.ctaText),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          Positioned(
            bottom: 16,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                items.length,
                (index) => AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: currentIndex == index ? 24 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(4),
                    color: currentIndex == index
                        ? const Color(0xFFC8A96A)
                        : Colors.white.withOpacity(0.5),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final VoidCallback seeAll;

  const _SectionHeader({required this.title, required this.seeAll});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenPadding),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: GoogleFonts.playfairDisplay(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: AppColors.primary,
            ),
          ),
          GestureDetector(
            onTap: seeAll,
            child: Text(
              'See All',
              style: GoogleFonts.poppins(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: const Color(0xFFC8A96A),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ProductHorizontalList extends StatelessWidget {
  final List<Product> products;

  const _ProductHorizontalList({required this.products});

  @override
  Widget build(BuildContext context) {
    if (products.isEmpty) {
      return const SizedBox.shrink();
    }
    return SizedBox(
      height: 280,
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenPadding),
        scrollDirection: Axis.horizontal,
        itemCount: products.length,
        itemBuilder: (context, index) {
          final product = products[index];
          return Padding(
            padding: const EdgeInsets.only(right: AppSpacing.md),
            child: _ProductCard(product: product),
          );
        },
      ),
    );
  }
}

class _ProductCard extends StatelessWidget {
  final Product product;

  const _ProductCard({required this.product});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        // Navigate to product detail (using your route)
        // Navigator.pushNamed(context, AppRoutes.productDetail, arguments: product.id);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Navigate to ${product.name}')),
        );
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeInOut,
        width: 160,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 20,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image with discount badge
            Stack(
              children: [
                ClipRRect(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
                  child: Image.network(
                    product.imageUrl,
                    height: 150,
                    width: double.infinity,
                    fit: BoxFit.cover,
                  ),
                ),
                if (product.discountPrice != null)
                  Positioned(
                    top: 8,
                    left: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Text(
                        '${((1 - product.discountPrice! / product.price) * 100).toInt()}% OFF',
                        style: GoogleFonts.poppins(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: GestureDetector(
                    onTap: () {
                      // Toggle wishlist
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Added ${product.name} to wishlist')),
                      );
                    },
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(
                        Icons.favorite_border,
                        size: 18,
                        color: AppColors.primary,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product.brand,
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textSecondary,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    product.name,
                    style: GoogleFonts.poppins(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: AppColors.textPrimary,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.star, color: Color(0xFFC8A96A), size: 14),
                      const SizedBox(width: 2),
                      Text(
                        product.rating.toString(),
                        style: GoogleFonts.poppins(
                          fontSize: 12,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Text(
                        '\$${product.price.toStringAsFixed(0)}',
                        style: GoogleFonts.poppins(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: AppColors.primary,
                        ),
                      ),
                      if (product.discountPrice != null) ...[
                        const SizedBox(width: 6),
                        Text(
                          '\$${product.discountPrice!.toStringAsFixed(0)}',
                          style: GoogleFonts.poppins(
                            fontSize: 12,
                            decoration: TextDecoration.lineThrough,
                            color: AppColors.textSecondary,
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BrandsRow extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final brands = ['Rolex', 'Omega', 'IWC', 'Cartier', 'Tag Heuer', 'Audemars Piguet'];
    return SizedBox(
      height: 60,
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenPadding),
        scrollDirection: Axis.horizontal,
        itemCount: brands.length,
        itemBuilder: (context, index) {
          return Container(
            margin: const EdgeInsets.only(right: AppSpacing.md),
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: AppColors.textSecondary.withOpacity(0.2)),
            ),
            child: Center(
              child: Text(
                brands[index],
                style: GoogleFonts.poppins(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: AppColors.textPrimary,
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _ReviewList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final reviews = [
      {'name': 'James R.', 'text': 'Absolutely stunning piece. The craftsmanship is unmatched.', 'rating': 5},
      {'name': 'Laura M.', 'text': 'Perfect everyday watch. Elegant and comfortable.', 'rating': 4.8},
      {'name': 'David K.', 'text': 'Best investment I\'ve made. Timeless design.', 'rating': 4.9},
    ];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AppSpacing.screenPadding),
      child: Column(
        children: reviews.map((review) {
          return Container(
            margin: const EdgeInsets.only(bottom: AppSpacing.md),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Row(
              children: [
                CircleAvatar(
                  backgroundColor: AppColors.primary.withOpacity(0.1),
                  child: Text(
  (review['name']! as String)[0],
  style: GoogleFonts.poppins(
    color: AppColors.primary,
    fontWeight: FontWeight.bold,
  ),
),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        review['name']! .toString(),
                        style: GoogleFonts.poppins(
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Row(
                        children: List.generate(5, (i) {
                          return Icon(
                           i < (review['rating']! as num).floor() ? Icons.star : Icons.star_border,
                            size: 16,
                            color: const Color(0xFFC8A96A),
                          );
                        }),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        review['text']! .toString(),
                        style: GoogleFonts.poppins(
                          fontSize: 13,
                          color: AppColors.textSecondary,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}