import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../providers/wishlist_provider.dart';

/// Clean Material 3 AppBar displaying title and dynamic Wishlist badge count.
class WishlistAppBar extends StatelessWidget implements PreferredSizeWidget {
  const WishlistAppBar({super.key});

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) {
    final count = context.select<WishlistProvider, int>(
      (p) => p.wishlistCount,
    );

    return AppBar(
      title: const Text(
        'My Wishlist',
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
      centerTitle: false,
      actions: [
        Padding(
          padding: const EdgeInsets.only(right: 16.0),
          child: Center(
            child: Badge.count(
              count: count,
              isLabelVisible: count > 0,
              child: const Icon(Icons.favorite_rounded, color: Colors.redAccent),
            ),
          ),
        ),
      ],
    );
  }
}