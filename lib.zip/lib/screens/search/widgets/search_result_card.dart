import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../models/product_model.dart';
import '../../../providers/wishlist_provider.dart';

/// Card item for search result listings with synchronized wishlist toggle.
class SearchResultCard extends StatelessWidget {
  final ProductModel product;
  final String currentUserId;
  final VoidCallback onTap;

  const SearchResultCard({
    super.key,
    required this.product,
    required this.currentUserId,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      elevation: 0,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: theme.colorScheme.outlineVariant.withOpacity(0.4),
        ),
      ),
      child: ListTile(
        onTap: onTap,
        leading: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.network(
            product.thumbnail,
            width: 48,
            height: 48,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => Container(
              width: 48,
              height: 48,
              color: theme.colorScheme.surfaceContainerHigh,
              child: const Icon(Icons.watch),
            ),
          ),
        ),
        title: Text(
          product.name,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Text('\$${product.price.toStringAsFixed(2)} • ${product.brandName}'),
        trailing: Selector<WishlistProvider, bool>(
          selector: (_, provider) =>
              provider.checkWishlistStatusLocally(product.id),
          builder: (context, isInWishlist, child) {
            return IconButton(
              icon: Icon(
                isInWishlist
                    ? Icons.favorite_rounded
                    : Icons.favorite_border_rounded,
                color: isInWishlist ? Colors.redAccent : null,
              ),
              onPressed: () {
                context.read<WishlistProvider>().toggleWishlist(
                      userId: currentUserId,
                      product: product,
                    );
              },
            );
          },
        ),
      ),
    );
  }
}