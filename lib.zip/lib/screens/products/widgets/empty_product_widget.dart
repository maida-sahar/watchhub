import 'package:flutter/material.dart';

class EmptyProductWidget extends StatelessWidget {
  final VoidCallback onReset;

  const EmptyProductWidget({super.key, required this.onReset});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.watch_off_outlined, size: 72, color: Colors.grey),
            const SizedBox(height: 16),
            const Text(
              'No Products Available',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text('We couldn\'t find any watches matching your criteria.', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: onReset, child: const Text('Reset Filters')),
          ],
        ),
      ),
    );
  }
}