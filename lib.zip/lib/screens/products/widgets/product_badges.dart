import 'package:flutter/material.dart';

class ProductBadges extends StatelessWidget {
  final bool isFeatured;
  final bool isBestSeller;
  final bool isNewArrival;
  final int stock;
  final int minStock;

  const ProductBadges({
    super.key,
    required this.isFeatured,
    required this.isBestSeller,
    required this.isNewArrival,
    required this.stock,
    this.minStock = 5,
  });

  @override
  Widget build(BuildContext context) {
    final List<Widget> badges = [];

    if (isFeatured) {
      badges.add(_buildBadge('Featured', Colors.amber.shade800, Colors.amber.shade50));
    }
    if (isBestSeller) {
      badges.add(_buildBadge('Best Seller', Colors.purple.shade700, Colors.purple.shade50));
    }
    if (isNewArrival) {
      badges.add(_buildBadge('New Arrival', Colors.blue.shade700, Colors.blue.shade50));
    }
    if (stock <= 0) {
      badges.add(_buildBadge('Out Of Stock', Colors.red.shade700, Colors.red.shade50));
    } else if (stock <= minStock) {
      badges.add(_buildBadge('Low Stock', Colors.orange.shade800, Colors.orange.shade50));
    }

    if (badges.isEmpty) return const SizedBox.shrink();

    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: badges,
    );
  }

  Widget _buildBadge(String label, Color textColor, Color bgColor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: textColor.withOpacity(0.3)),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: textColor,
        ),
      ),
    );
  }
}