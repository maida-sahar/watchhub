import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/product_model.dart';
import '../../providers/wishlist_provider.dart';
import 'widgets/product_image_slider.dart';

/// Details screen displaying product information and interactive wishlist toggle button.
class ProductDetailsScreen extends StatelessWidget {
  final ProductModel product;
  final String currentUserId;

  const ProductDetailsScreen({
    super.key,
    required this.product,
    required this.currentUserId,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(product.brandName),
        actions: [
          Selector<WishlistProvider, bool>(
            selector: (_, provider) =>
                provider.checkWishlistStatusLocally(product.id),
            builder: (context, isInWishlist, child) {
              return IconButton(
                icon: Icon(
                  isInWishlist
                      ? Icons.favorite_rounded
                      : Icons.favorite_border_rounded,
                  color: isInWishlist ? Colors.redAccent : null,
                ),
                onPressed: () {
                  context.read<WishlistProvider>().toggleWishlist(
                        userId: currentUserId,
                        product: product,
                      );
                },
              );
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Shows the thumbnail together with every gallery image
            // (product.galleryImages), with a swipeable slider and a
            // full-screen viewer on tap — instead of only the thumbnail.
            ProductImageSlider(
              thumbnail: product.thumbnail,
              galleryImages: product.galleryImages,
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product.name,
                    style: theme.textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    '\$${product.price.toStringAsFixed(2)}',
                    style: theme.textTheme.titleLarge?.copyWith(
                      color: theme.colorScheme.primary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    product.description,
                    style: theme.textTheme.bodyMedium,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}