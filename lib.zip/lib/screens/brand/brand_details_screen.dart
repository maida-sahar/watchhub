import 'package:flutter/material.dart';
import 'package:watch_hub/models/brand_model.dart';
import 'package:watch_hub/screens/brand/widgets/brand_banner.dart';
import 'package:watch_hub/screens/brand/widgets/brand_header.dart';
import 'package:watch_hub/screens/brand/widgets/brand_info.dart';
import 'package:watch_hub/widgets/empty_products_widget.dart';


class BrandDetailsScreen extends StatelessWidget {
  final BrandModel? brand;

  const BrandDetailsScreen({
    super.key,
    this.brand,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    // Retrieve model from route arguments if not directly injected via constructor
    final BrandModel? selectedBrand = brand ??
        (ModalRoute.of(context)?.settings.arguments as BrandModel?);

    // Invalid / Missing Model Handling
    if (selectedBrand == null) {
      return Scaffold(
        appBar: AppBar(
          title: const Text('Brand Details'),
        ),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.error_outline,
                  size: 64,
                  color: theme.colorScheme.error,
                ),
                const SizedBox(height: 16),
                Text(
                  'Brand Not Found',
                  style: theme.textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'The requested brand details could not be loaded. Please try again.',
                  textAlign: TextAlign.center,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
                const SizedBox(height: 24),
                ElevatedButton.icon(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.arrow_back),
                  label: const Text('Go Back'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: Padding(
          padding: const EdgeInsets.all(8.0),
          child: CircleAvatar(
            backgroundColor: theme.colorScheme.surface.withOpacity(0.85),
            child: IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: theme.colorScheme.onSurface,
              ),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Banner Section
            BrandBanner(bannerUrl: selectedBrand.bannerUrl),

            // Overlapping Header (Logo + Title + Badge)
            BrandHeader(brand: selectedBrand),

            // Brand Info & Statistics
            Transform.translate(
              offset: const Offset(0, -30),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    BrandInfo(brand: selectedBrand),
                    const SizedBox(height: 32),

                    // Products Section Title
                    Text(
                      'Products',
                      style: theme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Products Placeholder
                    const EmptyProductsWidget(),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}