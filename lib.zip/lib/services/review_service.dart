import 'package:image_picker/image_picker.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'storage_service.dart';

/// Representation of a product review document.
class ReviewModel {
  final String reviewId;
  final String productId;
  final String productName;
  final String productImageUrl;
  final String customerId;
  final String customerName;
  final String customerImageUrl;
  final double rating;
  final String reviewText;
  final String status; // 'pending', 'approved', 'rejected', 'hidden'
  final bool isReported;
  final String reportReason;
  final DateTime? reportDate;
  final DateTime createdAt;
  final DateTime updatedAt;

  const ReviewModel({
    required this.reviewId,
    required this.productId,
    required this.productName,
    required this.productImageUrl,
    required this.customerId,
    required this.customerName,
    required this.customerImageUrl,
    required this.rating,
    required this.reviewText,
    required this.status,
    required this.isReported,
    this.reportReason = '',
    this.reportDate,
    required this.createdAt,
    required this.updatedAt,
  });

  factory ReviewModel.fromMap(Map<String, dynamic> map, String id) {
    return ReviewModel(
      reviewId: id,
      productId: (map['productId'] as String?) ?? '',
      productName: (map['productName'] as String?) ?? '',
      productImageUrl: (map['productImageUrl'] as String?) ?? '',
      customerId: (map['customerId'] as String?) ?? '',
      customerName: (map['customerName'] as String?) ?? '',
      customerImageUrl: (map['customerImageUrl'] as String?) ?? '',
      rating: (map['rating'] as num?)?.toDouble() ?? 5.0,
      reviewText: (map['reviewText'] as String?) ?? '',
      status: (map['status'] as String?) ?? 'pending',
      isReported: (map['isReported'] as bool?) ?? false,
      reportReason: (map['reportReason'] as String?) ?? '',
      reportDate: map['reportDate'] != null ? _timestampToDate(map['reportDate']) : null,
      createdAt: _timestampToDate(map['createdAt']),
      updatedAt: _timestampToDate(map['updatedAt']),
    );
  }

  static DateTime _timestampToDate(dynamic value) {
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    return DateTime.now();
  }

  Map<String, dynamic> toMap() {
    return {
      'productId': productId,
      'productName': productName,
      'productImageUrl': productImageUrl,
      'customerId': customerId,
      'customerName': customerName,
      'customerImageUrl': customerImageUrl,
      'rating': rating,
      'reviewText': reviewText,
      'status': status,
      'isReported': isReported,
      'reportReason': reportReason,
      'reportDate': reportDate != null ? Timestamp.fromDate(reportDate!) : null,
      'createdAt': Timestamp.fromDate(createdAt),
      'updatedAt': Timestamp.fromDate(updatedAt),
    };
  }

  ReviewModel copyWith({
    String? status,
    bool? isReported,
    String? reportReason,
    DateTime? reportDate,
    DateTime? updatedAt,
  }) {
    return ReviewModel(
      reviewId: reviewId,
      productId: productId,
      productName: productName,
      productImageUrl: productImageUrl,
      customerId: customerId,
      customerName: customerName,
      customerImageUrl: customerImageUrl,
      rating: rating,
      reviewText: reviewText,
      status: status ?? this.status,
      isReported: isReported ?? this.isReported,
      reportReason: reportReason ?? this.reportReason,
      reportDate: reportDate ?? this.reportDate,
      createdAt: createdAt,
      updatedAt: updatedAt ?? DateTime.now(),
    );
  }
}

/// Custom Exception wrapper for ReviewService
class ReviewServiceException implements Exception {
  final String message;
  final String? code;
  const ReviewServiceException(this.message, {this.code});

  @override
  String toString() => message;
}

/// Service handling Firestore access for product reviews.
class ReviewService {
  final FirebaseFirestore _firestore;
  final StorageService _storage;

  static const String _reviewsCollection = 'reviews';

  ReviewService({FirebaseFirestore? firestore, StorageService? storage})
      : _firestore = firestore ?? FirebaseFirestore.instance,
        _storage = storage ?? StorageService();

  CollectionReference<Map<String, dynamic>> get _reviewsRef =>
      _firestore.collection(_reviewsCollection);

  /// Streams all reviews in real-time.
  Stream<List<ReviewModel>> watchAllReviews() {
    return _reviewsRef.snapshots().map((snapshot) {
      final List<ReviewModel> reviews = [];
      for (final doc in snapshot.docs) {
        try {
          reviews.add(ReviewModel.fromMap(doc.data(), doc.id));
        } catch (_) {
          // Skip invalid documents
        }
      }
      return reviews;
    });
  }

  /// Helper to update a review document status / flag fields
  Future<void> _updateReviewFields(String reviewId, Map<String, dynamic> fields) async {
    try {
      await _reviewsRef.doc(reviewId).update({
        ...fields,
        'updatedAt': Timestamp.fromDate(DateTime.now()),
      });
    } on FirebaseException catch (e) {
      throw ReviewServiceException(e.message ?? 'Firestore operation failed', code: e.code);
    } catch (e) {
      throw ReviewServiceException('An unexpected error occurred: $e');
    }
  }

  /// Approves a pending/reported review, confirming its visibility.
  Future<void> approveReview(String reviewId) async {
    await _updateReviewFields(reviewId, {
      'status': 'approved',
      'isReported': false,
      'reportReason': '',
      'reportDate': null,
    });
  }

  /// Rejects a review.
  Future<void> rejectReview(String reviewId) async {
    await _updateReviewFields(reviewId, {
      'status': 'rejected',
    });
  }

  /// Hides a review from public visibility.
  Future<void> hideReview(String reviewId) async {
    await _updateReviewFields(reviewId, {
      'status': 'hidden',
    });
  }

  /// Restores visibility of a hidden review to approved.
  Future<void> unhideReview(String reviewId) async {
    await _updateReviewFields(reviewId, {
      'status': 'approved',
    });
  }

  /// Deletes a review document permanently.
  Future<void> deleteReview(String reviewId) async {
    try {
      await _reviewsRef.doc(reviewId).delete();
    } on FirebaseException catch (e) {
      throw ReviewServiceException(e.message ?? 'Firestore delete failed', code: e.code);
    } catch (e) {
      throw ReviewServiceException('An unexpected error occurred: $e');
    }
  }

  /// Resolves a report, marking isReported = false and keeping it approved.
  Future<void> resolveReport(String reviewId) async {
    await _updateReviewFields(reviewId, {
      'isReported': false,
      'status': 'approved',
    });
  }

  /// Dismisses a report, clearing reasons and flagged state, resetting to pending/approved.
  Future<void> dismissReport(String reviewId) async {
    await _updateReviewFields(reviewId, {
      'isReported': false,
      'reportReason': '',
      'reportDate': null,
    });
  }

  /// Uploads review image to Supabase Storage and returns public URL.
  Future<String> uploadReviewImage({
    required String reviewId,
    required XFile imageFile,
  }) async {
    if (reviewId.trim().isEmpty) {
      throw const ReviewServiceException('Review ID is required to upload review image.');
    }
    try {
      if (await imageFile.length() == 0) {
        throw const ReviewServiceException('Image file is empty.');
      }
    } catch (e) {
      throw const ReviewServiceException('Image file does not exist.');
    }

    try {
      final uniqueName = _storage.generateUniqueFileName(imageFile);
      final path = 'reviews/$uniqueName';
      return await _storage.uploadImage(file: imageFile, path: path);
    } on StorageServiceException catch (e) {
      throw ReviewServiceException('Storage error: ${e.message}');
    } catch (e) {
      throw ReviewServiceException('An unexpected error occurred: $e');
    }
  }
}
